package pe.edu.upc.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SonicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SonicApplication.class, args);
	}

}
